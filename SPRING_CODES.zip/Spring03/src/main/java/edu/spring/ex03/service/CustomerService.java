package edu.spring.ex03.service;

public interface CustomerService {
	int createCustomer() throws Exception;
	int deleteCustomer();
	int updateCustomer() throws Exception;
}
